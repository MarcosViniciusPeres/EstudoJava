package br.com.introducao.operadores;

public class Operadores {
    public static void main(String[] args){
        int numero1 = 10;
        int numero2 = 20;
        int soma = numero1+numero2;
        int numeroInteiro = 20;
        long numeroLong= 20000L;

        double numeroDouble = 10d;
        float numeroFloat = 20f;


        numeroFloat = (float) numeroDouble;

        System.out.println("Resto da divisão "+ (20%2));
        System.out.println(numeroDouble);



    }

}
