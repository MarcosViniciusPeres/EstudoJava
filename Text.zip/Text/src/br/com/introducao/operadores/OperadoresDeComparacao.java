package br.com.introducao.operadores;

public class OperadoresDeComparacao {
    public static void main(String[] args){
        boolean dezMaiorQueVinte = 10 > 20;
        boolean dezMenorIgualVinte = 10 <=20;

        System.out.println(dezMaiorQueVinte);
        System.out.println(dezMenorIgualVinte);
        System.out.println(5==5);
        System.out.println(5!=5);
    }
}
