package br.com.introducao.arrays;

public class Arrays4 {
    public static void main(String[] args) {
        String[] nomes = {"Goku", "Picolo", "Gohan"};
        for(String aux : nomes){
            System.out.println(aux);
        }
    }
}
