package br.com.introducao.controleDeFluxo;

public class ExercicioControleFluxo3 {
    public static void main(String[] args) {
        int valor = 10; //sempre bom fazer assim para que não tenha qeu mudar no proprio for

        for(int i = 0 ; i <=valor; i++){
            if(i%2!=0){
                System.out.println("Numero é Impar: "+i);
            }

        }


    }


}


