package br.com.introducao;

public class Relatorio {
    public static void main(String[] args){
        String nome = "Vini";
        String endereco = "Rua Kiri, 273";
        String telefone = "(44) 997398432";
        int salario = 5000;
        char sexoMasculino = 'M';
        char sexoFeminino = 'F';
        int idade = 23;
        String estadoCivil = "Solteiro";

        System.out.println("O trabalhador(a) "+nome+" do sexo "+sexoMasculino+" idade "+idade+" estado civil "+estadoCivil+" e salario "+salario+" encontra-se empregado neste estabelecimento.");
        System.out.println("O "+nome+" domiciliado no endereco "+endereco+" e telefone "+telefone+" nao possui nenhum tipo de pendencia.");



    }

}
