package br.com.introducao;

public class ImprimindoVariaveis {
    public static void main(String[] args){
        int idade = 10;
        double salarioDouble = 3000;
        float salarioFinal = 3000;
        byte idadeByte = 12;
        short idadeShort = 32767;
        boolean verdadeiro = true;
        long numeroGrande = 1000L;
        char caracters = 'A'; //2 BYTES
        String nome = "Marcos";

        System.out.println("A IDADAE DA PESSOA EH: " +caracters);
    }
}
