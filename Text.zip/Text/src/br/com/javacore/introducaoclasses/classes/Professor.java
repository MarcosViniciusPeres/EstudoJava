package br.com.javacore.introducaoclasses.classes;

public class Professor {
    public String nome;
    public String matricula;
    public String rg;
    public String cpf;
}
