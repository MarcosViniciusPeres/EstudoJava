package br.com.javacore.introducaoclasses.classes;

public class Estudante {
    public String nome;
    public String matricula;
    public int idade;

}
