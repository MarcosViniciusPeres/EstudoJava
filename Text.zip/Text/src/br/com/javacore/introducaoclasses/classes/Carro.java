package br.com.javacore.introducaoclasses.classes;

public class Carro {
    public String placa;
    public String modelo;
    public float velocidadeMaxima;
}
